let nCount = selector => {
    $(selector).each(function() {
        $(this)
            .animate({
                Counter: $(this).text()
            }, {
                // A string or number determining how long the animation will run.
                duration: 4000,
                // A string indicating which easing function to use for the transition.
                easing: "swing",
                /**
                 * A function to be called for each animated property of each animated element. 
                 * This function provides an opportunity to
                 *  modify the Tween object to change the value of the property before it is set.
                 */
                step: function(value) {
                    $(this).text(Math.ceil(value));
                }
            });
    });
};

let a = 0;
$(window).scroll(function() {
    // The .offset() method allows us to retrieve the current position of an element  relative to the document
    let oTop = $(".numbers").offset().top - window.innerHeight;
    if (a == 0 && $(window).scrollTop() >= oTop) {
        a++;
        nCount(".rect > h1");
    }
});



/**
 *
 *  sticky navigation
 *
 */

let navbar = $(".navbar");

$(window).scroll(function() {
    // get the complete hight of window
    let oTop = $(".section-2").offset().top - window.innerHeight;
    if ($(window).scrollTop() > oTop) {
        navbar.addClass("sticky");
    } else {
        navbar.removeClass("sticky");
    }
});
/*-----ENG DZ-----*/
let ENG = document.querySelector('#ENG');
let DZ = document.querySelector('#DZ');
DZ.addEventListener('click', () => {
    setLanguage("DZ");
    localStorage.setItem("Lang", "DZ");

});
ENG.addEventListener('click', () => {
    setLanguage("ENG");
    localStorage.setItem("Lang", "ENG");

});
onload = () => {
    setLanguage(localStorage.getItem("Lang"));
};

function setLanguage(getLnaguage) {
    if (getLnaguage === "DZ") {
        document.body.style.direction = "rtl";
        document.querySelector('#home').innerHTML = "الصفحة الرئيسية";
        document.querySelector('#course').innerHTML = "الدروس";
        document.querySelector('#price').innerHTML = "السعر";
        document.querySelector('#pages').innerHTML = "الصفحات";
        document.querySelector('#generic').innerHTML = "عام ";
        document.querySelector('#element').innerHTML = "عنصر";
        document.querySelector('#fact').innerHTML = "معلومات الاتصال";
        document.querySelector('#about').innerHTML = "اقرأ المزيد";
        document.querySelector('#autor').innerHTML = "جميع الكتب التي تريدها";
        document.querySelector('#find').innerHTML = "جد الكتاب الذي تبحث عنه الان";
        document.querySelector('#btnby').innerHTML = "اشتر الان مقابل 5.99 دولار";
        document.querySelector('#dr').innerHTML = "د.ديفيد سميث";
        document.querySelector('#some').innerHTML = "بعض الميزات التي جعلتنا مميزين";
        document.querySelector('#client').innerHTML = "عميل راض";
        document.querySelector('#cups').innerHTML = "أكواب قهوة";
        document.querySelector('#subm').innerHTML = "تذاكر مرسلة";
        document.querySelector('#projects').innerHTML = "إجمالي المشاريع";
        document.querySelector('#purchase').innerHTML = "شراء ما تريد";
        document.querySelector('#pch1').innerHTML = "شراء الآن";
        document.querySelector('#pch2').innerHTML = "شراء الآن";
        document.querySelector('#pch3').innerHTML = "شراء الآن";




    } else {
        if (getLnaguage === "ENG") {
            document.body.style.direction = "ltr";
            document.querySelector('#home').innerHTML = "Home";
            document.querySelector('#course').innerHTML = "Course";
            document.querySelector('#price').innerHTML = "Price";
            document.querySelector('#pages').innerHTML = "Pages";
            document.querySelector('#generic').innerHTML = "Generic ";
            document.querySelector('#element').innerHTML = "Element";
            document.querySelector('#fact').innerHTML = "Contact";
            document.querySelector('#about').innerHTML = "Read more";
            document.querySelector('#autor').innerHTML = "All books you want";
            document.querySelector('#find').innerHTML = "Find the book you are looking for now";
            document.querySelector('#btnby').innerHTML = "By now for $5.99";
            document.querySelector('#dr').innerHTML = "Dr.Devid Smith";
            document.querySelector('#some').innerHTML = "Some Features That Made Us Unique";
            document.querySelector('#client').innerHTML = "Happy Client";
            document.querySelector('#cups').innerHTML = "Cups Coffee";
            document.querySelector('#subm').innerHTML = "Tickets Submitted";
            document.querySelector('#projects').innerHTML = "Total Projects";
            document.querySelector('#purchase').innerHTML = "Purchase Whatever You Want";
            document.querySelector('#pch1').innerHTML = "Purchase Now";
            document.querySelector('#pch2').innerHTML = "Purchase Now";
            document.querySelector('#pch3').innerHTML = "Purchase Now";





        }
    }
}